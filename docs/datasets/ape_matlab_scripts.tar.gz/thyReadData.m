function [data] = thyReadData(dataPath, dataName, dbtype)

% default data file to read is "interactive" mode 
if (nargin < 2)
	dataName = [];
end

% read data directory
if (nargin < 1)
	dataPath = '../data/part2pose/';
end

% Search for label index

fd = fopen([dataPath 'activityLabel.txt']);
nFolder = 1;
while (1)
	lline = fgetl(fd);
	[tokens] = textscan(lline,'%s','delimiter',',');
	if (numel(tokens{1}) < 2)
		break;
	end
	actionFileName{nFolder} = tokens{1}{1};
	labels{nFolder} = tokens{1}{2};
	nFolder = nFolder + 1;
end

% interactive mode  
if (isempty(dataName))
	% show dir 
	fprintf('=============================================================\n');
	fprintf('Data folder: %s\n', dataPath);
	for i = 1:numel(actionFileName)
		fprintf('(%3d) %16s \t\t[CLASS: %s]\n', i, actionFileName{i}, labels{i});
	end
	fprintf('=============================================================\n');
	action = input('Please enter the action: ');
	fprintf('=============================================================\n');
	% set target actionFileName and label
	dataName = actionFileName{action}; 
	loadDirName = [dataPath actionFileName{action}];
else
	% set target actionFileName and label
	loadDirName = [dataPath dataName];
end

% set label, find the matching label in the list 
for a = 1:numel(labels)
	if (strcmp(actionFileName{a},dataName))
		data.label	= labels{a};
		break;
	end
end

% For cambridge database

% make file names
skelFile = [loadDirName '.txt'];
videoFile = [loadDirName '.avi'];
depthFile = [loadDirName 'depth.avi'];

% load skeleton	

data.joints =	thyReadSkel(skelFile);
data.nFrames =  numel(dir([loadDirName '/image*.jpg'])); 

% load video
data.img = cell(1,data.nFrames);
data.depth = cell(1,data.nFrames);  
for a = 1:data.nFrames
	data.img{a} 	= sprintf('%s/image%05d.jpg', loadDirName, a - 1);
	data.depth{a} 	= sprintf('%s/depth%05d.jpg', loadDirName, a - 1);
end

