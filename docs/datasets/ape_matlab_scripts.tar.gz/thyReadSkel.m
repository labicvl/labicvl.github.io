function joints = thyReadSkel(jpath, nJoints, centered)
if (nargin < 3)
	centered = 0;
end
if (nargin < 2)
	nJoints = 15;
end
if (nargin < 1)
	jpath = '../data/kinectCam/handwave1.txt';
end
% just try to read the first user here?
fid = fopen(jpath);
if (fid == -1)
	fprintf('No 3D skeleton for this!\n');
	joints = [];
	return;
end
nFrames = fscanf(fid, '%d', 1);
joints.pos		= zeros(3,nJoints,nFrames);
joints.pconf	= zeros(1,nJoints,nFrames);
joints.ori		= zeros(3,nJoints,nFrames); 
joints.oconf	= zeros(1,nJoints,nFrames);
for a = 1:nFrames
	currentFrame	= fscanf(fid, '%d', 1); % no use now?
	currentId		= fscanf(fid, '%d', 1);	% no use now?
	for b = 1:nJoints
		joints.pos(:,b,a)	= fscanf(fid, '%f', [1 3]);
		joints.pconf(:,b,a) = fscanf(fid, '%f', [1]);
		joints.ori(:,b,a)	= rot2euler(fscanf(fid, '%f', [3 3]));
		joints.oconf(:,b,a) = fscanf(fid, '%f', [1]);
	end
end
if (centered == 1)
	joints.pos = bsxfun(@minus, joints.pos, joints.pos(:,3,:)); 
end
fclose(fid);
