% convert rotation matrix to euler angles
% should fix it
function [euler] = rot2euler(T)
if (size(T,1) == 2)
	euler(1) = atan2(T(2,1),T(1,1));
elseif (size(T,1) == 3)
    euler(1) = atan2(T(3,2),T(3,3));
	euler(2) = atan2(-T(3,1),sqrt(T(3,2)^2+T(3,3)^2));
    euler(3) = atan2(T(2,1),T(1,1));
else
	error('Wrong Size!');
end
